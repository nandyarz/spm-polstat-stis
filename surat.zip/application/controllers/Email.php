<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {

    public function __construct() {
        parent:: __construct();

        $this->load->helper('url');
    }

    public function index() {
        $judul = [
            'title' => 'Halaman Email',
            'sub_title' => 'Email'
        ];
        
        $this->load->view('templates/header', $judul);
        $this->load->view('templates/email');
        $this->load->view('templates/footer');
    }

    public function SendMail()
    {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('pesan', 'Pesan', 'required');

        if($this->form_validation->run()) {
            $email = $this->input->post('email');
            $subject = $this->input->post('subject');
            $pesan = $this->input->post('pesan');

            if(!empty($email)){
                // configuration to email & process
                $config = Array(
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1',
                    'protocol' => 'smtp',
                    'smtp_host' => 'smtp.gmail.com',
                    'smtp_user' => 'nandyarz@gmail.com',
                    'smtp_pass' => 'nandaa1142',
                    'smtp_port' => 465

                );

                $this->load->library('email', $config);
                $this->email->set_newline("\r\n");
                $this->email->initialize($config);

                // end config

                $this->email->from('emailfrom');
                $this->email->to($email);
                $this->email->subject($subject);
                $this->email->message($pesan);

                if($this->email->send()){
                    echo "email berhasil";
                } else{
                    show_error($this->email->print_debugger());
                }
            }
        }
    }
}