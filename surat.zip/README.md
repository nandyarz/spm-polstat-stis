<h3 align="center">Sistem Satuan Penjamin Mutu Politeknik Statistika STIS</h3>
